"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

// Pre-computed at module level — identical on server AND client.
// Never use Math.sin/cos inside JSX returned from a server component;
// floating-point results differ by the last bit between V8 versions.
const DOTS = [
  { cx: 228,    cy: 120,    big: true  },  // 0°
  { cx: 174,    cy: 213.4,  big: false },  // 60°
  { cx: 66,     cy: 213.4,  big: true  },  // 120°
  { cx: 12,     cy: 120,    big: false },  // 180°
  { cx: 66,     cy: 26.6,   big: true  },  // 240°
  { cx: 174,    cy: 26.6,   big: false },  // 300°
];

export function LoadingScreen() {
  const [visible, setVisible] = useState(true);
  const [fading,  setFading]  = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setFading(true),  2500);
    const t2 = setTimeout(() => setVisible(false), 3200);
    return () => { clearTimeout(t1); clearTimeout(t2) };
  }, []);

  if (!visible) return null;

  return (
    <div
      style={{
        position: "fixed", inset: 0, zIndex: 9999,
        background: "#000",
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        transition: "opacity 0.7s ease",
        opacity: fading ? 0 : 1,
        pointerEvents: fading ? "none" : "all",
      }}
    >
      <div style={{ position: "relative", width: 240, height: 240 }}>

        {/* Orbit ring + dots — 1.2 s fast spin */}
        <svg
          width="240" height="240" viewBox="0 0 240 240"
          style={{ position: "absolute", inset: 0, animation: "adu-orbit 1.2s linear infinite" }}
        >
          {/* Dashed track */}
          <circle
            cx="120" cy="120" r="108"
            fill="none"
            stroke="rgba(225,29,46,0.22)"
            strokeWidth="1"
            strokeDasharray="5 9"
          />
          {/* Static red dots */}
          {DOTS.map((d, i) => (
            <circle
              key={i}
              cx={d.cx} cy={d.cy}
              r={d.big ? 7 : 4.5}
              fill="#e11d2e"
              opacity={d.big ? 1 : 0.55}
            />
          ))}
        </svg>

        {/* Logo — counter-rotates to stay upright */}
        <div
          style={{
            position: "absolute", inset: 0,
            display: "flex", alignItems: "center", justifyContent: "center",
            animation: "adu-counter 1.2s linear infinite",
          }}
        >
          <Image
            src="/brand/ADU_Logo.png"
            alt="Abu Dhabi University"
            width={140} height={140}
            priority
            style={{ objectFit: "contain", width: 140, height: "auto" }}
          />
        </div>
      </div>

      <p style={{
        marginTop: 28,
        color: "rgba(255,255,255,0.45)",
        fontSize: 11,
        letterSpacing: "0.22em",
        textTransform: "uppercase",
        fontFamily: "system-ui, sans-serif",
      }}>
        Abu Dhabi University
      </p>

      <style>{`
        @keyframes adu-orbit   { to { transform: rotate(360deg)  } }
        @keyframes adu-counter { to { transform: rotate(-360deg) } }
      `}</style>
    </div>
  );
}
