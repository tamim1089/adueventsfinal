import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import MotionProvider from "@/components/MotionProvider";
import { LoadingScreen } from "@/components/ui/loading-screen";

const display = Space_Grotesk({
  variable: "--font-display",
  subsets: ["latin"],
  display: "swap",
  weight: ["500", "600", "700"],
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Events",
    template: "%s · ADU",
  },
  description:
    "Discover, organize, and document events across ADU — colleges, departments, and centers.",
};

export const viewport: Viewport = {
  themeColor: "#0c1020",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${display.variable} ${inter.variable} h-full antialiased`}
    >
      <body className="min-h-full">
        <LoadingScreen />
        <MotionProvider>{children}</MotionProvider>
      </body>
    </html>
  );
}
