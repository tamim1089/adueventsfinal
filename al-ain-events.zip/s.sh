#!/usr/bin/env bash
# ============================================================
# FINAL splash screen fix — one command does everything
# Run from: /home/hex/adu-apps/al-ain-events
# ============================================================
set -e

echo "▶ Installing sharp for image processing (if needed)..."
npm install --save-dev sharp 2>/dev/null || true

echo "▶ Writing splash-logo-processor script..."
cat > /tmp/process_logo.mjs << 'NODEEOF'
// Strips white background from adu-logo.png → saves as adu-logo-transparent.png
import sharp from 'sharp';
import { readFileSync, writeFileSync } from 'fs';

const src = 'public/brand/adu-logo.png';
const dst = 'public/brand/adu-logo-transparent.png';

const img   = sharp(src);
const meta  = await img.metadata();
const { data, info } = await img.ensureAlpha().raw().toBuffer({ resolveWithObject: true });

const pixels = new Uint8ClampedArray(data);

for (let i = 0; i < pixels.length; i += 4) {
  const r = pixels[i], g = pixels[i+1], b = pixels[i+2];
  // If pixel is near-white (all channels > 230), make transparent
  if (r > 230 && g > 230 && b > 230) {
    pixels[i+3] = 0; // fully transparent
  }
  // Slightly off-white (anti-aliasing edges) — partial transparency
  else if (r > 200 && g > 200 && b > 200) {
    const whiteness = Math.min(r, g, b);
    pixels[i+3] = Math.round(255 * (1 - (whiteness - 200) / 55));
  }
}

await sharp(Buffer.from(pixels), {
  raw: { width: info.width, height: info.height, channels: 4 }
})
  .png()
  .toFile(dst);

console.log(`✓ Saved transparent logo → ${dst}`);
NODEEOF

echo "▶ Processing logo (remove white background)..."
node /tmp/process_logo.mjs

echo "▶ Writing final loading-screen.tsx..."
cat > src/components/ui/loading-screen.tsx << 'EOF'
"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

// Static dot positions — pre-computed so server & client render identical HTML.
// (Never use Math.sin/cos inside JSX — floats differ between Node and V8 browser.)
const DOTS: { cx: number; cy: number; r: number; opacity: number }[] = [
  { cx: 228,   cy: 120,   r: 7,   opacity: 1    }, // 0°
  { cx: 174,   cy: 213,   r: 4.5, opacity: 0.55 }, // 60°
  { cx: 66,    cy: 213,   r: 7,   opacity: 1    }, // 120°
  { cx: 12,    cy: 120,   r: 4.5, opacity: 0.55 }, // 180°
  { cx: 66,    cy: 27,    r: 7,   opacity: 1    }, // 240°
  { cx: 174,   cy: 27,    r: 4.5, opacity: 0.55 }, // 300°
];

export function LoadingScreen() {
  const [visible, setVisible] = useState(true);
  const [fading,  setFading]  = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setFading(true),  2600);
    const t2 = setTimeout(() => setVisible(false), 3300);
    return () => { clearTimeout(t1); clearTimeout(t2) };
  }, []);

  if (!visible) return null;

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: "#000",
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      transition: "opacity 0.7s ease",
      opacity: fading ? 0 : 1,
      pointerEvents: fading ? "none" : "all",
    }}>

      {/* 240×240 orbit container */}
      <div style={{ position: "relative", width: 240, height: 240 }}>

        {/* Spinning ring + red dots */}
        <svg
          width="240" height="240" viewBox="0 0 240 240"
          aria-hidden="true"
          style={{ position: "absolute", inset: 0, animation: "adu-spin 1.2s linear infinite" }}
        >
          <circle cx="120" cy="120" r="108"
            fill="none"
            stroke="rgba(225,29,46,0.25)"
            strokeWidth="1.5"
            strokeDasharray="6 10"
          />
          {DOTS.map((d, i) => (
            <circle key={i} cx={d.cx} cy={d.cy} r={d.r} fill="#e11d2e" opacity={d.opacity} />
          ))}
        </svg>

        {/* Logo — counter-rotates to stay upright, white bg knocked out */}
        <div style={{
          position: "absolute", inset: 0,
          display: "flex", alignItems: "center", justifyContent: "center",
          animation: "adu-counter 1.2s linear infinite",
        }}>
          <Image
            src="/brand/adu-logo-transparent.png"
            alt="Abu Dhabi University"
            width={150} height={150}
            priority
            style={{ objectFit: "contain", width: 150, height: "auto" }}
          />
        </div>
      </div>

      {/* Tagline */}
      <p style={{
        marginTop: 24,
        color: "rgba(255,255,255,0.4)",
        fontSize: 11,
        letterSpacing: "0.22em",
        textTransform: "uppercase",
        fontFamily: "system-ui, sans-serif",
      }}>
        Abu Dhabi University
      </p>

      <style>{`
        @keyframes adu-spin    { to { transform: rotate(360deg)  } }
        @keyframes adu-counter { to { transform: rotate(-360deg) } }
      `}</style>
    </div>
  );
}
EOF

echo ""
echo "✅  Done! Splash screen is fixed:"
echo "   • adu-logo-transparent.png created (white bg removed)"
echo "   • Logo renders clean on black background"
echo "   • 6 red dots orbit at 1.2s speed"
echo "   • 3s total splash then fades"
echo "   • No hydration errors (static dot positions)"
echo ""
echo "Run: npm run dev"
